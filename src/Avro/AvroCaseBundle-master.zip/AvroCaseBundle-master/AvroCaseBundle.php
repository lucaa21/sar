<?php

namespace Avro\CaseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AvroCaseBundle extends Bundle
{
}
