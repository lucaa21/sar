<?php

namespace Avro\CsvBundle\Annotation;

/**
 * @Annotation
 */
class ImportExclude
{
}
