<?php

namespace Avro\CsvBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AvroCsvBundle extends Bundle
{
}
